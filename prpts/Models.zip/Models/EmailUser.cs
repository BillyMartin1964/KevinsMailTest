﻿using static prpts.RptSched;

namespace prpts.Models
{
    public class EmailUser
    {
        public string Name { get; set; }
        public string EmailAddress { get; set; }

        public EmailUser()
        {

        }

        public EmailUser(string name, string emailAddress)
        {
            Name = name;
            EmailAddress = emailAddress;
        }
    }
}