using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net.Mail;
using System.IO.Pipes;
using static prpts.RptSched;
using Microsoft.Identity.Client;
using prpts.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Net.Mime;
using System.Reflection.Metadata;
using static System.Windows.Forms.AxHost;
using System.Collections;
using prpts.Services;
//using Microsoft.Graph;

namespace prpts
{
    public partial class RptSched : System.Windows.Forms.Form
    {
        // Set up the client application ID and secret
        //read these from encrypted file instead and decrypt only.
        //string clientId = "0"; // "fa00187c-9223-4994-a5b2-7e55259f8846";
        //string clientSecret = "0"; // "5vg8Q~fYJa2_l6SiedvUdvM7l.P1aLWE6b9Akb98";
        //string tenantId = "0"; // "be84b8eb-a186-425e-b558-67785f8a8273";

        //public string strTO = "";
        //public string strCC = "";
        //public string strBody = "";
        //public string strSubject = "";

        // Declare CspParameters and RsaCryptoServiceProvider
        //// objects with global scope of your Form class.
        readonly CspParameters _cspp = new CspParameters();
        RSACryptoServiceProvider _rsa;

        // Path variables for source, encryption, and
        // decryption folders. Must end with a backslash.
        //const string EncrFolder = @"C:\Users\kperez\Documents\Projects\DRAW_EmailingC\DRAW_EmailingC\bin\Debug\Encrypt\";
        //const string DecrFolder = @"C:\Users\kperez\Documents\Projects\DRAW_EmailingC\DRAW_EmailingC\bin\Debug\Decrypt\";
        //const string SrcFolder = @"C:\Users\kperez\Documents\Projects\DRAW_EmailingC\DRAW_EmailingC\bin\Debug\";

        // Public key file
        //const string PubKeyFile = @"C:\Users\kperez\Documents\Projects\DRAW_EmailingC\DRAW_EmailingC\bin\Debug\encrypt\rsaPublicKey.txt";

        // Key container name for
        // private/public key value pair.
        //const string KeyName = "Key01";

        Email testEmail { get; set; }


        public RptSched()
        {
            InitializeComponent();

            testEmail = new Email(
                new EmailUser("Billy",
                "billy@sitesculptors.com"),
                new EmailUser("Kevin",
                "kperez@recyclingit.com"),
                "Test Email",
                new EmailBody("<p>This is the body of the test email</p>", "html")
                );

            LoadEmail(testEmail);
        }

        private void LoadEmail(Email testEmail)
        {

        }

        public async void SendEmail(Email email)
        {
            var secrets = FileService.GetSecrets();
            await EmailService.SendEmailAsync(tenantId, clientId, clientSecret, email);
        }

        private async void button2_Click(object sender, EventArgs e)
        {
             var secrets = FileService.GetSecrets();
            await SendEmail(tenantId, clientId, clientSecret, new Email(strSubject, strBody, strTO, strCC));

        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            if (_rsa is null)
            {
                MessageBox.Show("Key not set.");
            }
            else
            {
                // Display a dialog box to select the encrypted file.
                decryptOpenFileDialog.InitialDirectory = EncrFolder;
                if (decryptOpenFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fName = decryptOpenFileDialog.FileName;
                    if (fName != null)
                    {
                        FileService.DecryptFile(new FileInfo(fName));
                    }
                }
            }

        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if (_rsa is null)
            {
                MessageBox.Show("Key not set.");
            }
            else
            {
                // Display a dialog box to select a file to encrypt.
                encryptOpenFileDialog.InitialDirectory = SrcFolder;
                if (encryptOpenFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fName = encryptOpenFileDialog.FileName;
                    if (fName != null)
                    {
                        // Pass the file name without the path.
                        FileService.EncryptFile(new FileInfo(fName));
                    }
                }
            }

        }

        private void btnExportPK_Click(object sender, EventArgs e)
        {
            // Save the public key created by the RSA
            // to a file. Caution, persisting the
            // key to a file is a security risk.
            Directory.CreateDirectory(FileService.EncrFolder);
            using (var sw = new StreamWriter(FileService.PubKeyFile, false))
            {
                sw.Write(_rsa.ToXmlString(false));
            }
        }

        private void btnImportPK_Click(object sender, EventArgs e)
        {
            using (var sr = new StreamReader(FileService.PubKeyFile))
            {
                _cspp.KeyContainerName = KeyName;
                _rsa = new RSACryptoServiceProvider(_cspp);

                string keytxt = sr.ReadToEnd();
                _rsa.FromXmlString(keytxt);
                _rsa.PersistKeyInCsp = true;

                label1.Text = _rsa.PublicOnly
                ? $"Key: {_cspp.KeyContainerName} - Public Only"
                    : $"Key: {_cspp.KeyContainerName} - Full Key Pair";
            }

        }

        private void btnGetPK_Click(object sender, EventArgs e)
        {
            _cspp.KeyContainerName = KeyName;
            _rsa = new RSACryptoServiceProvider(_cspp)
            {
                PersistKeyInCsp = true
            };

            label1.Text = _rsa.PublicOnly
                ? $"Key: {_cspp.KeyContainerName} - Public Only"
                : $"Key: {_cspp.KeyContainerName} - Full Key Pair";

        }

        private void RptSched_Load(object sender, EventArgs e)
        {

        }

        private void tbSubject_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbCC_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbTO_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
